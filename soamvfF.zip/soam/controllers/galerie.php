<?php

include 'loader.php';
echo $twig->render('galerie.kmphtml.twig');