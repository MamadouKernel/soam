<?php

include 'loader.php';
echo $twig->render('index.kmphtml.twig');